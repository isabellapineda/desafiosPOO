
//clases

clase fecha
	definir dia como entero
	definir mes como entero 
	definir año como entero 


	//metodo
	metodo datos_fecha()
	mostrar "ingresar dia "
	leer dia
	mostrar "ingresar mes"
	leer mes
	mostrar "ingresar año"
	leer año
	fin metodo

fin clase
//clase
clase factura
	definir fecha como fecha
	definir codigo como entero
	definir monto como real 
	definir iva como real
	definir total como real
	
	//metodos
	metodo datos_factura()
	mostrar "ingresar fecha"
	leer fecha
	mostrar "ingresar el codigo de la factura "
	leer codigo
	mostrar "ingresar monto del accesorio"
	leer monto
	mostrar "ingresar monto del IVA"
	leer iva
	fin metodo

	metodo calcular_monto()
	 total=monto+iva
	fin metodo 


fin clase
//clase
clase accesorio
	definir nombre_acce como Caracter
	definir color como Caracter

	//metodo
	metodo datos_accesorio()
	mostrar"ingresar nombre del accesorio"
	leer nombre_acce
	mostrar "ingresar color"
	leer color
	fin metodo 


fin clase
//clase
clase cliente
	definir nombre como Caracter
	definir apellido como Caracter 
	definir ci como entero 

	//metodo
	metodo datos_cliente()
	mostrar "ingresar nombre del cliente"
	leer nombre
	mostrar "ingresar apellido del cliente"
	leer apellido
	mostrar "ingresar cedula de identidad de cliente"
	leer ci
	fin metodo


fin clase

//cominezo del algoritmo
algoritmo datos_factura
	//definicion de objetos
	definir cliente1 como cliente
	definir factura1 como factura
	definir accesorio1 como accesorio
	definir f1 como fecha

		//instanciacion
	cliente1= nuevo cliente()
	factura1= nuevo factura()
	accesorio1= nuevo accesorio()
	f1= nuevo fecha()



	//acseso a los atribulos de la clase a la que pertenece
	f1.datos_fecha()
	factura1.datos_factura()
	factura1.calcular_monto()
	accesorio1.datos_accesorio()
	cliente1.datos_cliente()


	//manipulacion de atributos, darle los valores a los atributos que apareceran en pantalla
	cliente1.nombre="isabella"
	cliente1.apellido="pineda"
	cliente1.ci=27215414

	factura1.codigo=1234567
	factura1.monto=2000000
	factura1.iva=3.4
	factura1.total=2000003.4

	f1.dia=12
	f1.mes=9
	f1=2018

	accesorio1.nombre="Jeep"
	accesorio1.color="Azul"

	//bloque de salida con los datos necesarios para una factura

	mostrar "factura N°: " factura1.codigo
	mostrar "Fecha " f1.dia "/" f1.mes"/" f1.año
	mostrar "cliente " cliente1.nombre " " cliente1.apellido " "cliente1.ci
	mostrar "Realizo una compra de " accesorio1.nombre " color " accesorio1.color
	mostrar	"tiene un monto de: " factura1.monto " bsS"
	mostrar "monto IVA: " factura1.iva
	mostrar "total ah cancelar es: " factura1.total 
	mostrar "GRACIAS POR TU COMPRA :D"




fin algoritmo
