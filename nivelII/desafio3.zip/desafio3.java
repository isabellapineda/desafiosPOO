/*Un banco permite a sus clientes a través de una app móvil 
conocer los saldos de sus instrumentos bancarios, cada cliente puede tener una cuenta
 bancaria y una tarjeta de crédito. Para ingresar a la app el sistema valida su nombre de usuario y contraseña, al ingresar  puede 
 isualizar el saldo disponible de la cuenta bancaria y el saldo disponible y deudor de la tarjeta de crédito.
Diseñe un algoritmo en pseudocodigo que valide usuario y contraseña de un cliente y permita ver los saldos de sus instrumentos 
bancarios*/

/*1.- Defina las clases cliente, cuenta bancaria y tarjeta de crédito, con los atributos correspondientes asignando tipo de dato 
adecuado y modificador de acceso privado

2.- Defina los métodos constructor por defecto y con parámetros para cada una de las clases

3.- Defina el método sobrecargado para la clase cliente (registra una cuenta bancaria o una tarjeta de crédito) considerando 
la diferencia de atributos entre cuenta bancaria y tarjeta de crédito. Defina además el método mostrar datos

4.- Desde el cuerpo principal defina e instancie los objetos, asigne valores del cliente y ejecute el método registrar instrumento
bancario

5.- Desde el cuerpo principal lea las entradas para iniciar sesión y valide el usuario y contraseña, si son correctos muestre 
la información de la cuenta y tarjeta de crédito*/

clase Cliente
	private definir nombre como Caracter 
	private definir ci como entero
	private definir Rif como entero
	private definir usuario como alfanumerico 
	private definir clave como alfanumerico

	public metodo getnombre() como caracter
	return nombre 
	fin metodo

	public metodo getci() como entero
	return ci
	fin metodo

	public metodo getRif() como entero
	return Rif 
	fin metodo

	public metodo getusuario() como alfanumerico
	return usuario
	fin metodo

	public metodo getclave() como alfanumerico
	return clave
	fin metodo

			//constructor por defecto
		public metodo cliente()
	
		finmetodo 
			//constructor con parametros
	    public metodo cliente(n,c,r,u,cla)
	    nombre=n
	    ci=c
	    Rif=r
	    usuario=u
	    clave=cla
	    fin metodo 

	 public metodo

	 //metodo sobrecargado
public metodo registrar(numero_cuenta,saldo)

 	numero_cuenta=client1.numero_cuenta
 	saldo=client1.saldo

finmetodo 

public metodo registrar(numero_tarjeta,saldo_tarjeta,saldo_deudor)

	numero_cuenta=client1.numero_cuenta
	saldo_tarjeta=cliente1.saldo_tarjeta
	saldo_deudor=client1.saldo_deudor
	
	

finmetodo 
	
	//metodo mostrar datos
metodo mostrar_datos()
	mostrar "tiene una cuenta nro:" numero_cuenta
	mostrar "con un saldo de: " saldo
	mostrar "una targeta numero: " numero_targeta
	mostrar "el saldo de la tergeta es: "saldo_tarjeta
	mostrar "saldo del deudor es: " saldo_deudor

fin metodo 



fin clase

clase Cuenta_bancaria
    private definir numero_cuenta como entero
    private  definir titular como cliente
    private definir saldo como Real 

    public metodo getnumero_cuenta() como entero
    return numero_cuenta
    fin metodo

    public metodo gettitular() como cliente
    return titular
    fin metodo

    public metodo getsaldo() como Real
    return saldo
    fin metodo

    //constructor por defecto
    public metodo cuenta_bancaria()
    fin metodo


    // constructor con parametro
    public metodo cuenta_bancaria(nu,s)
    numero_cuenta=nu
    saldo=s
	fin metodo


fin clase

clase Targeta_credito
	private definir numero_tarjeta como entero
	private definir saldo_deudor como real  
	private definir saldo_tarjeta como real

	public metodo getnumero_tarjeta() como entero
	return numero_tarjeta
	fin metodo


	public getsaldo_deudor() como entero
	return saldo_deudor
	fin metodo

	public getsaldo_tarjeta() como entero
	return saldo_tajeta
	fin metodo

	//constructos por defectos
	public metodo Tarjeta_credito()
	fin metodo


	//constructor con parametros
	public metodo tarjeta_credito(nt,sdeudor,starjeta)
	numero_tarjeta=nt
	saldo_deudor=sdeudor
	saldo_tajeta=starjeta
	fin metodo


fin clase 
 
 algoritmo
 definir client1 como Cliente
 definir cuent_clien como Cuenta_bancaria
 definir tarj_cliente como Tarjeta_credito
 

 client1=nuevo cliente("isabella",272154141,272151413,"isabellapn",2932033) 
 cuent_clien=nuevo cuenta_bancaria(013452732435454,380)
 tarj_cliente=nuevo tarjeta_credito(5362829201,201,45)

 client1.registrar(013452732435454,380)
 cliente1.registrar(5362829201,201,45)
 

	public metodo validacion()
definir usuario1 como alfanumerico
definir clave1 como alfanumerico    


mostrar "ingresar el usuario"
leer usuario1
mostrar "ingresar clave"
leer clave1 
 fin metodo


 if usuario1<>getusuario entonces
 	mostrar"usuario incorrecto"
 else 
 	if clave1<>getclave entonces 
 		mostrar "clave incorrecta"
 	else
 		mostrar "datos: " client1.mostrar_datos()
 	fin metodo

 client1.validacion()
 	

 fin algoritmo

